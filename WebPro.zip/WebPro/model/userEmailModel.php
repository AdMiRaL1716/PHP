<?php

class UserEmail {

    public $Email;

    public function __construct($Email) {
        $this->Email = $Email;
    }

}

?>