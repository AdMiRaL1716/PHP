<?php

class UserOneConfirm {

    public $Login;

    public function __construct($Login) {
        $this->Login = $Login;
    }

}

?>