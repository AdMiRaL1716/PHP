<?php

require_once 'inc/db.php';

include_once("model/userModel.php");
include_once("model/userOneModel.php");

include_once("model/Model.php");
include_once 'controller/Render.php';
include_once("controller/Controller.php");

include 'route/routing.php';

echo $response;
?>
